AI Constitution & Law Explainer Website - MVP Todo
Core Features to Implement:
Main Landing Page - Professional hero section with AI law explainer introduction
AI Question Interface - Input field for legal questions with AI-powered responses
Constitution Search - Search through constitutional articles and amendments
State Laws Database - Browse and search state-specific laws
Rights Explainer - Common rights explained in simple terms
Legal Aid Locator - Directory of legal aid offices by location
FAQ Section - Common legal questions and answers
Files to Create:
src/pages/Index.tsx - Main landing page with hero and navigation
src/components/AIQuestionInterface.tsx - AI chat interface for legal questions
src/components/ConstitutionSearch.tsx - Constitution article search
src/components/StateLaws.tsx - State laws browser
src/components/RightsExplainer.tsx - Rights education section
src/components/LegalAidLocator.tsx - Legal aid office finder
src/components/Navigation.tsx - Main navigation component
src/data/legalData.ts - Mock legal data and responses
Design Approach:
Professional, trustworthy design with legal theme
Accessible language for citizens
Clean, modern interface using Shadcn-UI components
Responsive design for mobile and desktop
Clear call-to-actions and easy navigation