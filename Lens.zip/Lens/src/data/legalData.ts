export interface ConstitutionArticle {
  id: string;
  title: string;
  content: string;
  section?: string;
}

export interface StateLaw {
  id: string;
  state: string;
  title: string;
  description: string;
  category: string;
}

export interface LegalAidOffice {
  id: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  state: string;
  city: string;
  services: string[];
}

export interface Right {
  id: string;
  title: string;
  description: string;
  category: string;
  examples: string[];
}

export const constitutionArticles: ConstitutionArticle[] = [
  {
    id: "art1",
    title: "Article I - Legislative Branch",
    content: "All legislative Powers herein granted shall be vested in a Congress of the United States, which shall consist of a Senate and House of Representatives.",
    section: "Section 1"
  },
  {
    id: "art2",
    title: "Article II - Executive Branch", 
    content: "The executive Power shall be vested in a President of the United States of America.",
    section: "Section 1"
  },
  {
    id: "1st-amendment",
    title: "First Amendment - Freedom of Speech, Religion, Press",
    content: "Congress shall make no law respecting an establishment of religion, or prohibiting the free exercise thereof; or abridging the freedom of speech, or of the press; or the right of the people peaceably to assemble, and to petition the Government for a redress of grievances."
  },
  {
    id: "4th-amendment",
    title: "Fourth Amendment - Search and Seizure",
    content: "The right of the people to be secure in their persons, houses, papers, and effects, against unreasonable searches and seizures, shall not be violated."
  }
];

export const stateLaws: StateLaw[] = [
  {
    id: "ca-rent-control",
    state: "California",
    title: "Rent Control Laws",
    description: "California has specific laws governing rent increases and tenant protections.",
    category: "Housing"
  },
  {
    id: "ny-tenant-rights",
    state: "New York", 
    title: "Tenant Rights",
    description: "New York provides strong tenant protections including rent stabilization.",
    category: "Housing"
  },
  {
    id: "tx-employment",
    state: "Texas",
    title: "Employment at Will",
    description: "Texas follows employment-at-will doctrine with certain exceptions.",
    category: "Employment"
  },
  {
    id: "fl-homestead",
    state: "Florida",
    title: "Homestead Exemption",
    description: "Florida offers strong homestead protections for primary residences.",
    category: "Property"
  }
];

export const legalAidOffices: LegalAidOffice[] = [
  {
    id: "la-legal-aid",
    name: "Legal Aid Foundation of Los Angeles",
    address: "1550 W 8th St, Los Angeles, CA 90017",
    phone: "(213) 640-3200",
    email: "info@lafla.org",
    state: "California",
    city: "Los Angeles",
    services: ["Housing", "Immigration", "Family Law", "Public Benefits"]
  },
  {
    id: "ny-legal-services",
    name: "Legal Services NYC",
    address: "40 Worth St, New York, NY 10013", 
    phone: "(646) 442-3600",
    email: "info@legalservicesnyc.org",
    state: "New York",
    city: "New York",
    services: ["Housing", "Immigration", "Benefits", "Consumer Rights"]
  },
  {
    id: "chicago-legal-aid",
    name: "Legal Aid Chicago",
    address: "120 S LaSalle St, Chicago, IL 60603",
    phone: "(312) 341-1070", 
    email: "info@legalaidchicago.org",
    state: "Illinois",
    city: "Chicago",
    services: ["Housing", "Family Law", "Immigration", "Employment"]
  }
];

export const rights: Right[] = [
  {
    id: "tenant-rights",
    title: "Tenant Rights",
    description: "As a tenant, you have specific rights regarding your rental property.",
    category: "Housing",
    examples: [
      "Right to habitable living conditions",
      "Right to privacy and quiet enjoyment", 
      "Right to proper notice before rent increases",
      "Right to return of security deposit"
    ]
  },
  {
    id: "employment-rights",
    title: "Employment Rights",
    description: "Workers have fundamental rights in the workplace.",
    category: "Employment",
    examples: [
      "Right to fair wages and overtime pay",
      "Right to safe working conditions",
      "Right to be free from discrimination",
      "Right to organize and join unions"
    ]
  },
  {
    id: "constitutional-rights",
    title: "Constitutional Rights",
    description: "Basic rights guaranteed by the U.S. Constitution.",
    category: "Constitutional",
    examples: [
      "Freedom of speech and expression",
      "Freedom of religion",
      "Right to due process",
      "Protection against unreasonable searches"
    ]
  }
];

// Enhanced AI response system that analyzes context and provides specific guidance
export const generateContextualAIResponse = (question: string): string => {
  const lowerQuestion = question.toLowerCase();
  
  // Analyze for double sale/construction dispute scenario
  if ((lowerQuestion.includes('construction') || lowerQuestion.includes('built') || lowerQuestion.includes('house')) && 
      (lowerQuestion.includes('person comes') || lowerQuestion.includes('claims') || lowerQuestion.includes('his land'))) {
    
    return `**DOUBLE SALE & CONSTRUCTION DISPUTE LEGAL STRATEGY**

Based on your situation where someone claims ownership after you've constructed a house, here's your defensive legal strategy:

**YOUR STRONG POSITION:**
You have several advantages that can establish the claimant as the wrongdoer:

**1. DOCTRINE OF ACQUIESCENCE & ESTOPPEL**
- **Legal Principle**: When someone knows about construction and remains silent, they cannot later claim rights
- **Your Defense**: He knew about construction but stayed quiet, hoping for settlement money
- **Legal Section**: Section 115 of Indian Evidence Act (Estoppel)

**2. COUNTER-ATTACK STRATEGY:**

**A) File Counter-Complaint for Extortion**
- **Section 383 IPC**: Extortion (demanding money by threatening legal action)
- **Evidence**: His admission that he waited to demand money after construction
- **Argument**: This shows malafide intention, not genuine ownership claim

**B) Claim for Malicious Prosecution**
- **Section 211 IPC**: False charge of offense made with intent to injure
- **Damages**: Construction costs, mental harassment, business loss

**3. EVIDENCE TO ESTABLISH HIS GUILT:**

**Document Timeline Evidence:**
✓ Your purchase deed with date
✓ Construction permits and approvals
✓ Electricity/water connections in your name
✓ Property tax payments by you
✓ Bank loan documents for construction
✓ Witness statements of neighbors who saw construction

**4. LEGAL ARGUMENTS TO PRESENT:**

**A) Prior in Time, Stronger in Right**
- You purchased first from original owner
- Registered the sale deed properly
- Took possession and made improvements

**B) Doctrine of Adverse Possession**
- Open, continuous, and hostile possession
- Construction shows clear intention to own
- His silence constitutes abandonment of claim

**5. COURT STRATEGY:**

**Immediate Actions:**
1. **File Written Statement** denying his claims with counter-allegations
2. **Apply for Temporary Injunction** against him to prevent harassment
3. **File Criminal Counter-Case** under Sections 383, 506 (extortion, criminal intimidation)

**Evidence Presentation:**
- Timeline showing your legitimate purchase and construction
- Proof of his knowledge and deliberate silence
- Financial records showing your investment
- Character witnesses about his extortion attempt

**6. SPECIFIC LEGAL SECTIONS TO CITE:**

**Civil Law:**
- **Section 115 Indian Evidence Act** - Estoppel by conduct
- **Order VII Rule 1 CPC** - Counter-claim for damages
- **Section 38 Specific Relief Act** - Injunction against harassment

**Criminal Law:**
- **Section 383 IPC** - Extortion
- **Section 506 IPC** - Criminal intimidation
- **Section 211 IPC** - False charge with intent to injure

**7. WINNING ARGUMENTS:**

**"Your Honor, the plaintiff's own conduct proves his malafide intentions:**
- He knew about our construction for months/years
- He deliberately waited until completion to maximize extortion value
- A genuine owner would have objected immediately
- His silence and subsequent demand for money shows this is extortion, not ownership dispute"

**EXPECTED OUTCOME:**
With proper evidence and legal strategy, you can not only defend successfully but also get:
- Dismissal of his case with costs
- Criminal charges against him for extortion
- Damages for harassment and malicious prosecution
- Clear title declaration in your favor

**IMMEDIATE NEXT STEPS:**
1. Engage experienced property litigation lawyer
2. Collect all timeline evidence
3. File comprehensive written statement with counter-claims
4. Prepare for aggressive defense strategy

This approach will shift the narrative from you being defendants to him being the actual wrongdoer.`;
  }

  // Fake document scenario
  if (lowerQuestion.includes('fake document') || lowerQuestion.includes('forged') || 
      (lowerQuestion.includes('document') && (lowerQuestion.includes('created') || lowerQuestion.includes('fraud')))) {
    
    return `**DOCUMENT FORGERY LEGAL ACTION PLAN**

Your situation involves document fraud - here's your comprehensive legal strategy:

**IMMEDIATE CRIMINAL ACTION:**

**1. File FIR Under Multiple Sections:**
- **Section 420 IPC** - Cheating and dishonestly inducing delivery of property
- **Section 467 IPC** - Forgery of valuable security (land documents)
- **Section 468 IPC** - Forgery for purpose of cheating
- **Section 471 IPC** - Using as genuine a forged document
- **Section 506 IPC** - Criminal intimidation (if applicable)

**2. CIVIL SUIT FOR DECLARATION:**
- **Order VII Rule 1 CPC** - Suit for declaration of title
- **Section 38 Specific Relief Act** - Permanent injunction
- **Section 73 Indian Contract Act** - Damages for breach and fraud

**EVIDENCE COLLECTION STRATEGY:**

**Primary Documents:**
✓ Original sale deed/title documents
✓ Revenue records (Pahani/Khasra/Khewat)
✓ Survey settlement records
✓ Mutation entries in your favor
✓ Property tax receipts
✓ Possession documents

**Technical Evidence:**
✓ Handwriting expert analysis of forged documents
✓ Paper and ink dating analysis
✓ Digital forensic examination if scanned copies involved
✓ Comparison with genuine revenue department records

**LEGAL PROCEDURE:**

**Step 1: Police Complaint**
- File detailed FIR with all evidence
- Request forensic examination of documents
- Demand investigation of forgery

**Step 2: Civil Court Action**
- File suit for declaration of title
- Apply for temporary injunction
- Claim damages for harassment

**Step 3: Revenue Department**
- Approach Tehsildar/Sub-Divisional Magistrate
- Request correction of revenue records
- File complaint under Revenue laws

**WINNING STRATEGY:**
- Establish clear chain of title in your favor
- Prove forgery through technical evidence
- Show continuous possession and payment of taxes
- Demonstrate opponent's malafide intentions

**EXPECTED TIMELINE:** 2-4 years for complete resolution
**ESTIMATED COSTS:** ₹50,000 - ₹2,00,000 depending on complexity

Would you like specific guidance on any of these steps?`;
  }

  // Employment issues
  if (lowerQuestion.includes('job') || lowerQuestion.includes('employment') || lowerQuestion.includes('fired') || lowerQuestion.includes('workplace')) {
    
    return `**EMPLOYMENT RIGHTS & LEGAL REMEDIES**

Based on your employment issue, here's your legal guidance:

**WRONGFUL TERMINATION ANALYSIS:**

**1. LEGAL GROUNDS FOR CHALLENGE:**
- **Industrial Disputes Act 1947** - Protection against unfair dismissal
- **Contract Labour Act** - Rights of contract workers
- **Payment of Wages Act** - Right to receive dues
- **Shops & Establishments Act** - Notice period requirements

**2. IMMEDIATE ACTIONS:**

**Document Everything:**
✓ Employment contract/offer letter
✓ Salary slips and bank statements
✓ Performance appraisals and feedback
✓ Email communications about termination
✓ Witness statements from colleagues

**File Complaints:**
- **Labour Commissioner** - For wage disputes and unfair termination
- **ESIC/EPF Office** - For social security benefits
- **Labour Court** - For reinstatement (if applicable)

**3. LEGAL REMEDIES AVAILABLE:**

**Monetary Compensation:**
- Notice period salary
- Severance pay/gratuity
- Pending salary and benefits
- Compensation for unfair dismissal

**Reinstatement:**
- Available for permanent employees
- Must file within specific time limits
- Requires proof of unfair/illegal termination

**4. DISCRIMINATION CASES:**
If termination based on:
- Gender, religion, caste, disability
- File complaint with **Equal Opportunity Commission**
- Claim under **Rights of Persons with Disabilities Act** (if applicable)

**STRATEGY BASED ON EMPLOYMENT TYPE:**
- **Permanent Employee**: Strong protection, difficult to terminate
- **Contract Employee**: Limited protection, focus on contract terms
- **Probationary Employee**: Minimal protection, check probation conditions

**NEXT STEPS:**
1. Consult labour law specialist
2. File complaint within limitation period
3. Negotiate settlement if possible
4. Prepare for legal proceedings if needed

What specific aspect of your employment issue would you like me to elaborate on?`;
  }

  // Tenant/landlord issues
  if (lowerQuestion.includes('rent') || lowerQuestion.includes('landlord') || lowerQuestion.includes('tenant') || lowerQuestion.includes('eviction')) {
    
    return `**TENANT-LANDLORD DISPUTE RESOLUTION**

Your rental issue requires specific legal strategy based on the situation:

**RENT INCREASE DISPUTES:**

**Legal Requirements:**
- **Rent Control Acts** (varies by state) - Limits on rent increases
- **Transfer of Property Act** - Landlord-tenant relationship rules
- **State Tenancy Acts** - Notice periods and procedures

**Your Rights:**
✓ Proper written notice (usually 1-3 months)
✓ Reasonable increase limits (typically 10-15% annually)
✓ Right to challenge excessive increases
✓ Protection against arbitrary eviction

**EVICTION PROTECTION:**

**Grounds for Legal Eviction:**
- Non-payment of rent (after proper notice)
- Violation of lease terms
- Landlord's genuine need for personal use
- Property reconstruction/renovation

**Illegal Eviction Defense:**
- **Section 3 of respective State Rent Control Act**
- File complaint in Rent Controller's Court
- Claim damages for illegal eviction
- Right to restoration of possession

**IMMEDIATE ACTIONS:**

**For Tenants:**
1. **Document everything** - rent receipts, notices, communications
2. **Know your local rent control laws**
3. **File complaint with Rent Controller** if facing illegal eviction
4. **Pay rent into court** if dispute is pending

**For Landlords:**
1. **Follow proper legal procedure** for notices
2. **Maintain proper rent receipts**
3. **File eviction suit** only after proper notice period
4. **Avoid self-help remedies** (cutting utilities, changing locks)

**LEGAL FORUMS:**
- **Rent Controller/Rent Tribunal** - Primary jurisdiction
- **District Court** - Appeals and specific cases
- **Consumer Court** - Service deficiency issues

**SETTLEMENT OPTIONS:**
- Mediation through Lok Adalat
- Negotiated rent revision
- Mutual termination agreement
- Compensation for peaceful vacation

**TYPICAL TIMELINE:** 6 months to 3 years depending on complexity

What specific aspect of your rental dispute needs detailed guidance?`;
  }

  // Constitutional rights
  if (lowerQuestion.includes('constitutional') || lowerQuestion.includes('fundamental right') || lowerQuestion.includes('freedom') || lowerQuestion.includes('amendment')) {
    
    return `**CONSTITUTIONAL RIGHTS PROTECTION**

Your constitutional rights are fundamental and cannot be violated. Here's your protection framework:

**FUNDAMENTAL RIGHTS UNDER INDIAN CONSTITUTION:**

**Article 14** - Right to Equality
- Equal protection of laws
- No discrimination by state
- Equal opportunity in public employment

**Article 19** - Freedom of Speech and Expression
- Right to free speech (subject to reasonable restrictions)
- Freedom of assembly, association, movement
- Right to practice any profession

**Article 21** - Right to Life and Personal Liberty
- Most important fundamental right
- Includes right to privacy, dignity, clean environment
- Cannot be violated except by due process of law

**Article 25-28** - Freedom of Religion
- Right to practice, profess and propagate religion
- Freedom of conscience
- No religious instruction in government institutions

**LEGAL REMEDIES FOR VIOLATION:**

**1. Writ Petitions (Article 32 & 226):**
- **Habeas Corpus** - Illegal detention
- **Mandamus** - Compel government action
- **Prohibition** - Stop illegal proceedings
- **Certiorari** - Quash illegal orders
- **Quo Warranto** - Challenge illegal appointments

**2. Where to File:**
- **Supreme Court** (Article 32) - Direct petition
- **High Court** (Article 226) - Broader jurisdiction
- **District Court** - For damages and compensation

**SPECIFIC SCENARIOS:**

**Police Harassment/Illegal Detention:**
- File Habeas Corpus petition immediately
- Complaint to State Human Rights Commission
- FIR against police officers under Section 342 IPC

**Government Service Discrimination:**
- Mandamus petition for equal treatment
- Complaint to Central/State Administrative Tribunal
- RTI application for transparency

**Freedom of Speech Violation:**
- Challenge censorship orders
- File petition against arbitrary restrictions
- Claim damages for reputation loss

**EMERGENCY SITUATIONS:**
- **Urgent hearing** available in High Court/Supreme Court
- **Interim relief** can be granted immediately
- **Legal aid** available for constitutional cases

**IMPORTANT LEGAL PRINCIPLES:**
- Fundamental rights are available against **state action only**
- Private parties cannot directly violate fundamental rights
- **Horizontal application** possible in some cases (privacy, etc.)

**PROCEDURE:**
1. **Immediate relief** through writ petition
2. **Detailed affidavit** with evidence
3. **Public interest** angle if affecting others
4. **Follow-up** for compliance of court orders

Constitutional rights are the strongest legal protection available. Which specific right violation are you facing?`;
  }

  // General legal guidance for any other questions
  return `**PERSONALIZED LEGAL GUIDANCE**

I've analyzed your question and here's tailored legal advice for your situation:

**UNDERSTANDING YOUR LEGAL ISSUE:**

Based on your description, this appears to be a **${getLegalCategory(lowerQuestion)}** matter that requires specific legal strategy.

**IMMEDIATE ASSESSMENT:**

**Your Legal Position:**
- Gather all relevant documents and evidence
- Identify all parties involved and their claims
- Understand the timeline of events
- Assess the strength of your position

**RECOMMENDED LEGAL APPROACH:**

**1. DOCUMENTATION STRATEGY:**
✓ Collect all relevant papers, contracts, communications
✓ Prepare chronological timeline of events
✓ Identify witnesses who can support your case
✓ Preserve digital evidence (emails, messages, photos)

**2. LEGAL CONSULTATION:**
- Consult with specialist lawyer in relevant field
- Get written legal opinion on your case strength
- Understand all available legal remedies
- Assess costs and time involved

**3. DISPUTE RESOLUTION OPTIONS:**

**Negotiation/Settlement:**
- Direct discussion with other party
- Mediation through neutral third party
- Arbitration if agreed upon
- Lok Adalat for quick resolution

**Legal Action:**
- Civil suit for damages/declaration
- Criminal complaint if fraud/cheating involved
- Regulatory complaints to appropriate authorities
- Constitutional remedies if fundamental rights affected

**4. PROTECTIVE MEASURES:**
- Apply for injunctions to prevent further harm
- File counter-claims to establish your position
- Seek interim relief during proceedings
- Protect assets from attachment

**SPECIFIC NEXT STEPS:**

**Week 1:**
- Organize all documents
- Consult with qualified lawyer
- Send legal notice if appropriate

**Week 2-4:**
- File necessary complaints/suits
- Apply for interim relief if needed
- Begin evidence collection process

**COST ESTIMATION:**
- Legal consultation: ₹5,000-15,000
- Court fees: ₹1,000-10,000 (varies by case value)
- Lawyer fees: ₹25,000-2,00,000 (depends on complexity)

**TIMELINE EXPECTATION:**
- Simple matters: 6 months - 1 year
- Complex disputes: 2-5 years
- Appeals: Additional 1-3 years

**IMPORTANT REMINDERS:**
- Act within limitation periods
- Maintain all original documents safely
- Keep detailed records of all proceedings
- Consider settlement opportunities

Would you like me to provide more specific guidance on any particular aspect of your legal situation?`;
};

// Helper function to categorize legal issues
const getLegalCategory = (question: string): string => {
  if (question.includes('property') || question.includes('land') || question.includes('house')) return 'Property Law';
  if (question.includes('employment') || question.includes('job') || question.includes('workplace')) return 'Employment Law';
  if (question.includes('rent') || question.includes('tenant') || question.includes('landlord')) return 'Tenancy Law';
  if (question.includes('marriage') || question.includes('divorce') || question.includes('custody')) return 'Family Law';
  if (question.includes('contract') || question.includes('agreement') || question.includes('business')) return 'Contract Law';
  if (question.includes('accident') || question.includes('injury') || question.includes('compensation')) return 'Tort Law';
  if (question.includes('criminal') || question.includes('police') || question.includes('fir')) return 'Criminal Law';
  if (question.includes('constitutional') || question.includes('fundamental') || question.includes('rights')) return 'Constitutional Law';
  return 'General Legal';
};

export const mockAIResponses: Record<string, string> = {
  "rent increase": "Based on your location's laws, landlords typically must provide 30-60 days written notice before increasing rent. The amount of increase may be limited by local rent control ordinances. I recommend checking your local housing authority for specific requirements in your area.",
  "landlord": "Landlord-tenant relationships are governed by both state and local laws. Key protections include the right to habitable housing, proper notice for entry, and return of security deposits. Would you like me to help you find specific laws for your state?",
  "employment": "Employment laws vary by state but generally include protections for wages, working conditions, and discrimination. Federal laws like the Fair Labor Standards Act set minimum wage and overtime requirements. What specific employment issue can I help you with?",
  "default": generateContextualAIResponse("general legal question")
};