export const indianConstitutionalArticles = [
  {
    article: "Article 14",
    title: "Right to Equality",
    content: "The State shall not deny to any person equality before the law or the equal protection of the laws within the territory of India.",
    category: "Fundamental Rights"
  },
  {
    article: "Article 19",
    title: "Protection of certain rights regarding freedom of speech etc.",
    content: "All citizens shall have the right to freedom of speech and expression, to assemble peaceably and without arms, to form associations or unions, to move freely throughout the territory of India, to reside and settle in any part of the territory of India, and to practise any profession, or to carry on any occupation, trade or business.",
    category: "Fundamental Rights"
  },
  {
    article: "Article 21",
    title: "Protection of life and personal liberty",
    content: "No person shall be deprived of his life or personal liberty except according to procedure established by law.",
    category: "Fundamental Rights"
  },
  {
    article: "Article 32",
    title: "Right to Constitutional Remedies",
    content: "The right to move the Supreme Court by appropriate proceedings for the enforcement of the fundamental rights is guaranteed.",
    category: "Fundamental Rights"
  },
  {
    article: "Article 226",
    title: "Power of High Courts to issue writs",
    content: "Every High Court shall have power, throughout the territories in relation to which it exercises jurisdiction, to issue to any person or authority, including in appropriate cases, any Government, within those territories directions, orders or writs, including writs in the nature of habeas corpus, mandamus, prohibition, certiorari and quo-warranto, or any of them, for the enforcement of any of the fundamental rights and for any other purpose.",
    category: "Constitutional Remedies"
  }
];

export const indianLegalActs = [
  {
    act: "Indian Penal Code, 1860",
    sections: ["Section 420 - Cheating", "Section 498A - Domestic Violence", "Section 354 - Assault on Women"],
    category: "Criminal Law"
  },
  {
    act: "Code of Civil Procedure, 1908",
    sections: ["Order 39 - Temporary Injunctions", "Order 6 - Pleadings", "Section 9 - Civil Court Jurisdiction"],
    category: "Civil Law"
  },
  {
    act: "Transfer of Property Act, 1882",
    sections: ["Section 54 - Sale of Property", "Section 17 - Mortgage", "Section 105 - Lease"],
    category: "Property Law"
  },
  {
    act: "Consumer Protection Act, 2019",
    sections: ["Section 2 - Consumer Definition", "Section 35 - Consumer Complaints", "Section 87 - Penalties"],
    category: "Consumer Law"
  }
];

export const generateIndianLegalResponse = (question: string): string => {
  const lowerQuestion = question.toLowerCase();
  
  // Property and Land Disputes
  if (lowerQuestion.includes('land') || lowerQuestion.includes('property') || lowerQuestion.includes('house') || lowerQuestion.includes('construction')) {
    return `**Indian Property Law Analysis**

Based on your property dispute, here's guidance under Indian legal framework:

**Immediate Legal Actions:**
✓ File complaint under Section 420 IPC (Cheating) if fraud is involved
✓ Approach Civil Court for declaration suit under Transfer of Property Act
✓ File police complaint for criminal trespass under Section 441 IPC
✓ Seek injunction under Code of Civil Procedure (CPC) Order 39

**Evidence Collection (Indian Law):**
✓ Original sale deed and registered documents
✓ Revenue records (Khata, Pahani, Survey Settlement)
✓ Mutation records from Village Revenue Office
✓ Title verification report from Sub-Registrar office

**Legal Remedies Available:**
• **Civil Remedy**: Declaration suit under CPC for establishing title
• **Criminal Remedy**: FIR under IPC Section 420, 467, 468 for forgery
• **Revenue Remedy**: Complaint to Tehsildar/Collector under Land Revenue Act

**Court Procedures:**
1. File suit in appropriate Civil Court (based on property value)
2. Pay court fees as per Court Fees Act
3. Serve notice to opposite party under CPC Order 5
4. Attend hearings and present evidence

**Constitutional Protection:**
Your property rights are protected under Article 300A of Indian Constitution. No person can be deprived of property except by authority of law.

**Next Steps:**
Consult property lawyer immediately and gather all revenue documents. Time limitation under Limitation Act applies - typically 12 years for property disputes.

**Estimated Timeline:** 6 months to 2 years (depending on case complexity)
**Estimated Cost:** ₹50,000 - ₹2,00,000 (including lawyer fees and court charges)`;
  }
  
  // Employment and Labor Law
  if (lowerQuestion.includes('job') || lowerQuestion.includes('employment') || lowerQuestion.includes('salary') || lowerQuestion.includes('termination') || lowerQuestion.includes('fired')) {
    return `**Indian Employment Law Guidance**

Your employment issue falls under Indian labor laws. Here's your legal recourse:

**Applicable Laws:**
✓ Industrial Disputes Act, 1947
✓ Employees' Provident Fund Act, 1952
✓ Payment of Wages Act, 1936
✓ Sexual Harassment of Women at Workplace Act, 2013

**Immediate Actions:**
✓ File complaint with Labor Commissioner within 45 days
✓ Approach Industrial Tribunal for wrongful termination
✓ File case under Payment of Wages Act for salary recovery
✓ Complaint to EPFO for PF/Gratuity issues

**Legal Remedies:**
• **Reinstatement**: Under Industrial Disputes Act Section 25F
• **Compensation**: Back wages + compensation for illegal termination
• **Criminal Case**: Under IPC if salary withholding is willful

**Required Documents:**
✓ Employment contract/Appointment letter
✓ Salary slips and bank statements
✓ Termination letter (if any)
✓ PF/ESI registration details

**Constitutional Rights:**
Article 19(1)(g) guarantees right to practice profession. Article 21 includes right to livelihood.

**Forum for Complaint:**
1. Labor Court (for individual disputes)
2. Industrial Tribunal (for workmen disputes)
3. High Court (writ petition under Article 226)

**Estimated Timeline:** 3-12 months
**Potential Compensation:** 3-6 months salary + back wages

Contact nearest Labor Inspector or approach legal aid clinic for immediate assistance.`;
  }
  
  // Tenant Rights and Rent Issues
  if (lowerQuestion.includes('rent') || lowerQuestion.includes('landlord') || lowerQuestion.includes('tenant') || lowerQuestion.includes('eviction')) {
    return `**Indian Tenancy Law Rights**

Your tenant rights are protected under various state Rent Control Acts:

**Applicable Laws:**
✓ State Rent Control Act (varies by state)
✓ Transfer of Property Act, 1882 (Section 105-117)
✓ Indian Contract Act, 1872
✓ Consumer Protection Act, 2019

**Tenant Rights:**
✓ Right against arbitrary rent increase (as per Rent Control Act)
✓ Right to reasonable notice period (minimum 15 days to 1 month)
✓ Right to basic amenities and repairs
✓ Protection against illegal eviction

**Legal Remedies:**
• **Rent Controller**: Complaint for excessive rent increase
• **Civil Court**: Suit for specific performance of lease terms
• **Consumer Forum**: For deficiency in services
• **Police**: For illegal eviction/harassment

**Eviction Grounds (Landlord must prove):**
1. Non-payment of rent for 4+ months
2. Subletting without permission
3. Damage to property
4. Personal necessity of landlord (with court permission)

**Required Notice:**
Landlord must give proper legal notice as per state law before eviction proceedings.

**Your Action Plan:**
1. Send legal notice to landlord citing violation
2. File complaint with Rent Controller
3. Maintain payment records
4. Document all communications

**Constitutional Protection:**
Article 19(1)(e) guarantees right to reside. No eviction without due process under Article 21.

**Estimated Timeline:** 6 months to 2 years
**Estimated Cost:** ₹25,000 - ₹75,000

Consult local tenant rights organization or legal aid for immediate assistance.`;
  }
  
  // Constitutional Rights Violation
  if (lowerQuestion.includes('police') || lowerQuestion.includes('arrest') || lowerQuestion.includes('search') || lowerQuestion.includes('constitutional') || lowerQuestion.includes('rights')) {
    return `**Constitutional Rights Violation - Indian Law**

Your fundamental rights under Indian Constitution may have been violated:

**Violated Rights Analysis:**
✓ Article 21 - Right to Life and Personal Liberty
✓ Article 22 - Protection against arbitrary arrest
✓ Article 20 - Protection from self-incrimination
✓ Article 19 - Freedom of speech and movement

**Police Powers and Limitations:**
• **Arrest**: Only with warrant (except cognizable offenses)
• **Search**: Requires search warrant under CrPC Section 165
• **Detention**: Must inform grounds under Article 22(1)
• **Custodial Rights**: Right to lawyer, medical examination

**Legal Remedies Available:**
✓ **Habeas Corpus**: Article 32/226 for illegal detention
✓ **Compensation**: Under D.K. Basu guidelines for custodial violence
✓ **Criminal Case**: Against police under IPC Section 342, 323
✓ **Departmental Action**: Complaint to SP/DGP

**Immediate Actions:**
1. File complaint with National/State Human Rights Commission
2. Approach High Court under Article 226 (writ jurisdiction)
3. File FIR against erring police officers
4. Seek medical examination if physical harm

**Supreme Court Guidelines:**
• D.K. Basu case guidelines for arrest procedures
• Arnesh Kumar case guidelines to prevent arbitrary arrests
• Right to free legal aid under Article 39A

**Evidence Collection:**
✓ Medical reports of injuries
✓ Witness statements
✓ CCTV footage if available
✓ Station House Diary entries

**Constitutional Remedy:**
Article 32 gives you right to directly approach Supreme Court for fundamental rights enforcement.

**Estimated Timeline:** Immediate relief within 24-72 hours
**Compensation:** ₹1 lakh to ₹10 lakh (depending on case severity)

Contact nearest legal aid clinic or human rights organization immediately.`;
  }
  
  // Family and Marriage Law
  if (lowerQuestion.includes('marriage') || lowerQuestion.includes('divorce') || lowerQuestion.includes('dowry') || lowerQuestion.includes('domestic violence') || lowerQuestion.includes('498a')) {
    return `**Indian Family Law Guidance**

Your family law issue falls under Indian personal laws:

**Applicable Laws:**
✓ Hindu Marriage Act, 1955 (for Hindus, Buddhists, Sikhs, Jains)
✓ Indian Christian Marriage Act, 1872
✓ Muslim Personal Law (Shariat) Application Act, 1937
✓ Protection of Women from Domestic Violence Act, 2005

**Immediate Safety Measures:**
✓ Call Women Helpline 1091
✓ File complaint at nearest Women Police Station
✓ Obtain medical certificate (if physical violence occurred)
✓ Collect witness statements

**Legal Provisions:**
• **Section 498A IPC**: Dowry harassment and cruelty
• **Domestic Violence Act 2005**: Protection orders and maintenance
• **Hindu Marriage Act**: Grounds for divorce and maintenance
• **Muslim Personal Law**: Talaq, Mahr, and maintenance rights

**Available Legal Remedies:**
• **Protection Order**: Immediate safety from domestic violence
• **Residence Order**: Right to stay in matrimonial home
• **Maintenance Order**: Monthly financial support
• **Custody Order**: Child custody arrangements

**Divorce Grounds (Hindu Marriage Act):**
1. Cruelty (physical or mental)
2. Adultery
3. Conversion to another religion
4. Mental disorder
5. Communicable disease
6. Desertion (2+ years)

**Children's Rights:**
• Custody preference to mother (up to age 5)
• Right to education and maintenance
• Right to meet both parents

**Estimated Timeline:** 6 months to 3 years
**Estimated Cost:** ₹50,000 - ₹3,00,000

Contact nearest Mahila Thana or legal aid for immediate assistance.`;
  }
  
  // Consumer Rights and Protection
  if (lowerQuestion.includes('consumer') || lowerQuestion.includes('product') || lowerQuestion.includes('service') || lowerQuestion.includes('refund') || lowerQuestion.includes('defective')) {
    return `**Indian Consumer Protection Law Guidance**

Your consumer issue falls under Consumer Protection Act, 2019:

**Immediate Actions:**
✓ Preserve purchase receipt and bills
✓ Take photos/videos of defective product/service
✓ Send written complaint to company
✓ File complaint on National Consumer Helpline 1915

**Consumer Rights under Act:**
• **Right to Safety**: Protection from hazardous goods/services
• **Right to Information**: Product quality, quantity, and standards
• **Right to Choose**: Freedom to select from variety of products
• **Right to be Heard**: File complaints and seek redressal

**Consumer Court Jurisdiction:**
• **District Commission**: Cases up to ₹1 crore
• **State Commission**: Cases ₹1-10 crore
• **National Commission**: Cases above ₹10 crore

**Service Deficiency Examples:**
• Banking service delays or errors
• Insurance claim unfair settlement
• Medical negligence
• Educational institution poor service
• Telecom service problems

**Available Relief:**
1. **Refund**: Return of defective product and money back
2. **Replacement**: New product or better service
3. **Compensation**: Damages for loss and harassment
4. **Punitive Damages**: For deliberate negligence

**Online Complaint Process:**
• National Consumer Helpline: 1915
• e-Daakhil Portal: edaakhil.nic.in
• Consumer Online Dispute Resolution

**Timeline**: 2 years from date of cause of action
**Court Fee**: 1% of claim value (minimum ₹500)

Contact nearest Consumer Forum or legal aid for guidance.`;
  }
  
  // Default response for general queries
  return `**Indian Legal System Guidance**

Welcome to LawLens AI - your guide to Indian Constitutional and Legal framework.

**Indian Legal Structure:**
✓ **Constitutional Law**: Supreme law under Constitution of India
✓ **Criminal Law**: Indian Penal Code, CrPC, Evidence Act
✓ **Civil Law**: Contract Act, Property laws, Family laws
✓ **Special Acts**: Consumer Protection, RTI, POSH Act

**Your Legal Rights:**
• **Fundamental Rights**: Articles 12-35 (enforceable in court)
• **Directive Principles**: Articles 36-51 (policy guidelines)
• **Legal Aid**: Free legal services under Article 39A

**Court System:**
1. **Supreme Court**: Final appellate court
2. **High Courts**: State-level constitutional courts
3. **District Courts**: Trial courts for civil/criminal cases
4. **Specialized Courts**: Family, Consumer, Labor courts

**How to Proceed:**
✓ Identify applicable law for your issue
✓ Gather relevant documents and evidence
✓ Approach appropriate forum/court
✓ Seek legal aid if financially constrained

**Free Legal Resources:**
• **National Legal Services Authority (NALSA)**: Call 15100
• **State Legal Services Authority**
• **District Legal Services Committee**
• **Lok Adalat** for amicable settlement

**Constitutional Remedies:**
- **Article 32**: Right to Constitutional Remedies (Supreme Court)
- **Article 226**: Writ jurisdiction (High Court)
- **Article 136**: Special Leave Petition (Supreme Court)

**Important Helplines:**
• Police: 100
• Women Helpline: 1091
• Consumer Helpline: 1915
• Legal Aid: 15100

Please describe your specific legal situation for detailed guidance under Indian law.`;
};