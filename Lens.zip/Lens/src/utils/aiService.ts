import { generateIndianLegalResponse } from '@/data/indianLegalData';

export const generateContextualResponse = (question: string): string => {
  return generateIndianLegalResponse(question);
};