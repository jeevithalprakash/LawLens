import { useState, useEffect } from 'react';
import Navigation from '@/components/Navigation';
import AIQuestionInterface from '@/components/AIQuestionInterface';
import ConstitutionSearch from '@/components/ConstitutionSearch';
import StateLaws from '@/components/StateLaws';
import RightsExplainer from '@/components/RightsExplainer';
import LegalAidLocator from '@/components/LegalAidLocator';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Scale, 
  Search, 
  BookOpen, 
  Users, 
  MapPin, 
  MessageSquare,
  Shield,
  Gavel,
  FileText,
  Phone,
  Mail,
  Globe,
  Sparkles,
  ArrowRight,
  CheckCircle
} from 'lucide-react';

export default function Index() {
  const [activeSection, setActiveSection] = useState('home');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const features = [
    {
      icon: MessageSquare,
      title: 'AI Legal Assistant',
      description: 'Get personalized legal guidance based on Indian Constitution, IPC, CrPC, and Central/State Acts',
      gradient: 'from-blue-500 to-cyan-400',
      id: 'ai-chat',
      delay: 'delay-100'
    },
    {
      icon: BookOpen,
      title: 'Constitution Explorer',
      description: 'Search Articles, Fundamental Rights, Directive Principles, and Constitutional Amendments',
      gradient: 'from-emerald-500 to-teal-400',
      id: 'constitution',
      delay: 'delay-200'
    },
    {
      icon: Users,
      title: 'Indian Laws Database',
      description: 'Browse IPC, CrPC, Contract Act, Property Act, and 1000+ Central & State laws',
      gradient: 'from-purple-500 to-pink-400',
      id: 'state-laws',
      delay: 'delay-300'
    },
    {
      icon: Shield,
      title: 'Fundamental Rights',
      description: 'Understand your constitutional rights under Articles 12-35 with real case examples',
      gradient: 'from-orange-500 to-red-400',
      id: 'rights',
      delay: 'delay-400'
    },
    {
      icon: MapPin,
      title: 'Legal Aid Services',
      description: 'Find NALSA centers, District Legal Services, and free legal aid across India',
      gradient: 'from-rose-500 to-pink-400',
      id: 'legal-aid',
      delay: 'delay-500'
    },
    {
      icon: Gavel,
      title: 'Court Procedures',
      description: 'Step-by-step guide for filing cases in Indian courts from District to Supreme Court',
      gradient: 'from-indigo-500 to-purple-400',
      id: 'procedures',
      delay: 'delay-600'
    }
  ];

  const stats = [
    { label: 'Constitutional Articles', value: '395+', icon: BookOpen, color: 'text-blue-600' },
    { label: 'Indian Legal Acts', value: '1000+', icon: FileText, color: 'text-emerald-600' },
    { label: 'Supreme Court Judgments', value: '10,000+', icon: Gavel, color: 'text-purple-600' },
    { label: 'Legal Aid Centers', value: '15,000+', icon: MapPin, color: 'text-orange-600' }
  ];

  const benefits = [
    'Free constitutional guidance based on Indian law',
    'AI-powered legal research and case analysis',
    '24/7 access to legal information and procedures',
    'Multilingual support for Indian regional languages',
    'Direct connection to NALSA legal aid services',
    'Real-time updates on legal amendments and judgments'
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'ai-chat':
        return <AIQuestionInterface />;
      case 'constitution':
        return <ConstitutionSearch />;
      case 'state-laws':
        return <StateLaws />;
      case 'rights':
        return <RightsExplainer />;
      case 'legal-aid':
        return <LegalAidLocator />;
      default:
        return (
          <div className="space-y-20">
            {/* Animated Hero Section */}
            <section className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-700 to-indigo-800"></div>
              <div className="absolute inset-0 bg-black/20"></div>
              <div className="absolute inset-0">
                <div className="absolute top-10 left-10 w-72 h-72 bg-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute bottom-10 right-10 w-96 h-96 bg-purple-400/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-400/10 rounded-full blur-2xl animate-spin-slow"></div>
              </div>
              
              <div className="relative text-center py-24 px-6">
                <div className={`max-w-5xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
                  <div className="flex items-center justify-center mb-8 animate-bounce">
                    <div className="relative">
                      <div className="w-24 h-24 bg-gradient-to-br from-white/30 to-white/10 rounded-full flex items-center justify-center backdrop-blur-sm border border-white/20 shadow-2xl">
                        <Scale className="h-14 w-14 text-white drop-shadow-lg" />
                      </div>
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center animate-ping">
                        <Sparkles className="h-4 w-4 text-white" />
                      </div>
                    </div>
                  </div>
                  
                  <h1 className="text-7xl font-black mb-6 text-white drop-shadow-2xl">
                    <span className="bg-gradient-to-r from-white via-blue-100 to-cyan-200 bg-clip-text text-transparent">
                      LawLens
                    </span>
                  </h1>
                  
                  <div className="text-2xl text-blue-100 mb-8 font-light tracking-wide">
                    <span className="inline-block animate-fade-in-up delay-300">Indian AI-Powered</span>
                    <span className="inline-block animate-fade-in-up delay-500 ml-2 text-yellow-300 font-semibold">Legal Guidance</span>
                    <span className="inline-block animate-fade-in-up delay-700 ml-2">Platform</span>
                  </div>
                  
                  <p className="text-xl mb-12 leading-relaxed text-blue-50/90 max-w-4xl mx-auto animate-fade-in-up delay-1000">
                    Experience the future of legal assistance with our revolutionary AI platform. Get instant, personalized guidance based on the 
                    <span className="font-semibold text-yellow-300"> Indian Constitution, IPC, CrPC</span>, and 1000+ Central & State Acts. 
                    Navigate the Indian legal system with unprecedented ease and confidence.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-6 justify-center animate-fade-in-up delay-1200">
                    <Button 
                      size="lg" 
                      className="bg-gradient-to-r from-white to-blue-50 text-blue-700 hover:from-blue-50 hover:to-white shadow-2xl hover:shadow-white/25 transition-all duration-300 transform hover:scale-105 border-0 px-8 py-4 text-lg font-semibold"
                      onClick={() => setActiveSection('ai-chat')}
                    >
                      <MessageSquare className="mr-3 h-6 w-6" />
                      Start AI Consultation
                      <ArrowRight className="ml-3 h-6 w-6 animate-pulse" />
                    </Button>
                    <Button 
                      size="lg" 
                      className="bg-gradient-to-r from-transparent to-transparent border-2 border-white/30 text-white hover:bg-white/10 backdrop-blur-sm shadow-2xl hover:shadow-white/25 transition-all duration-300 transform hover:scale-105 px-8 py-4 text-lg font-semibold"
                      onClick={() => setActiveSection('constitution')}
                    >
                      <BookOpen className="mr-3 h-6 w-6" />
                      Explore Constitution
                    </Button>
                  </div>
                </div>
              </div>
            </section>

            {/* Animated Stats Section */}
            <section className="py-16 relative">
              <div className="absolute inset-0 bg-gradient-to-r from-gray-50 to-blue-50/30"></div>
              <div className="relative">
                <h2 className="text-4xl font-bold text-center mb-16 text-gray-900">
                  Trusted by Legal Professionals Across India
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-6xl mx-auto">
                  {stats.map((stat, index) => {
                    const Icon = stat.icon;
                    return (
                      <Card key={index} className="text-center group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                        <CardContent className="pt-8 pb-6">
                          <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-gray-100 to-gray-200 mb-4 group-hover:scale-110 transition-transform duration-300 ${stat.color}`}>
                            <Icon className="h-8 w-8" />
                          </div>
                          <div className="text-4xl font-black mb-2 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent">
                            {stat.value}
                          </div>
                          <div className="text-sm font-medium text-gray-600">{stat.label}</div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* Enhanced Features Grid */}
            <section className="py-16">
              <div className="text-center mb-16">
                <h2 className="text-5xl font-black mb-6 bg-gradient-to-r from-gray-900 via-blue-800 to-purple-800 bg-clip-text text-transparent">
                  Revolutionary Legal Technology
                </h2>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                  Powered by advanced AI and comprehensive Indian legal databases including Constitution, IPC, CrPC, and state legislation
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
                {features.map((feature, index) => {
                  const Icon = feature.icon;
                  return (
                    <Card 
                      key={index} 
                      className={`group hover:shadow-2xl transition-all duration-700 cursor-pointer transform hover:-translate-y-3 hover:rotate-1 bg-white border-0 shadow-lg overflow-hidden animate-fade-in-up ${feature.delay}`}
                      onClick={() => setActiveSection(feature.id)}
                    >
                      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-gray-50/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                      <CardHeader className="relative">
                        <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 shadow-lg`}>
                          <Icon className="h-8 w-8 text-white drop-shadow-sm" />
                        </div>
                        <CardTitle className="text-2xl font-bold group-hover:text-blue-700 transition-colors duration-300">
                          {feature.title}
                        </CardTitle>
                        <CardDescription className="text-gray-600 leading-relaxed text-base">
                          {feature.description}
                        </CardDescription>
                        <div className="pt-4 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
                          <ArrowRight className="h-5 w-5 text-blue-600" />
                        </div>
                      </CardHeader>
                    </Card>
                  );
                })}
              </div>
            </section>

            {/* How It Works with Enhanced Animation */}
            <section className="py-20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50"></div>
              <div className="absolute top-0 left-0 w-full h-full">
                <div className="absolute top-20 left-20 w-64 h-64 bg-blue-200/20 rounded-full blur-3xl animate-float"></div>
                <div className="absolute bottom-20 right-20 w-80 h-80 bg-purple-200/20 rounded-full blur-3xl animate-float-delay"></div>
              </div>
              
              <div className="relative max-w-6xl mx-auto px-6">
                <div className="text-center mb-16">
                  <h2 className="text-5xl font-black mb-6 bg-gradient-to-r from-blue-800 to-purple-800 bg-clip-text text-transparent">
                    How LawLens Transforms Legal Access
                  </h2>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    Experience seamless legal guidance through our intelligent three-step process
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                  {[
                    { icon: Search, title: 'Describe Your Legal Issue', desc: 'Tell our advanced AI about your situation with Indian legal context', color: 'from-blue-500 to-cyan-400', delay: 'delay-200' },
                    { icon: MessageSquare, title: 'Get Constitutional Analysis', desc: 'Receive comprehensive guidance based on Indian Constitution and relevant acts', color: 'from-emerald-500 to-teal-400', delay: 'delay-400' },
                    { icon: Gavel, title: 'Take Legal Action', desc: 'Follow step-by-step procedures for Indian courts and authorities', color: 'from-purple-500 to-pink-400', delay: 'delay-600' }
                  ].map((step, index) => {
                    const Icon = step.icon;
                    return (
                      <div key={index} className={`text-center group animate-fade-in-up ${step.delay}`}>
                        <div className="relative mb-8">
                          <div className={`w-24 h-24 bg-gradient-to-br ${step.color} rounded-full flex items-center justify-center mx-auto shadow-2xl group-hover:scale-110 transition-all duration-500`}>
                            <Icon className="h-12 w-12 text-white drop-shadow-lg" />
                          </div>
                          <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-lg">
                            {index + 1}
                          </div>
                        </div>
                        <h3 className="text-2xl font-bold mb-4 text-gray-900 group-hover:text-blue-700 transition-colors duration-300">
                          {step.title}
                        </h3>
                        <p className="text-gray-600 leading-relaxed text-lg">{step.desc}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </section>

            {/* Benefits Section */}
            <section className="py-16">
              <div className="max-w-6xl mx-auto px-6">
                <div className="text-center mb-16">
                  <h2 className="text-4xl font-black mb-6 text-gray-900">
                    Why Choose LawLens?
                  </h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {benefits.map((benefit, index) => (
                    <div key={index} className={`flex items-center space-x-4 p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 animate-fade-in-up delay-${(index + 1) * 100}`}>
                      <div className="flex-shrink-0">
                        <CheckCircle className="h-8 w-8 text-emerald-500" />
                      </div>
                      <p className="text-lg font-medium text-gray-800">{benefit}</p>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* Indian Legal Areas with Animation */}
            <section className="py-16 bg-gradient-to-r from-gray-900 to-blue-900 text-white">
              <div className="max-w-6xl mx-auto px-6">
                <h2 className="text-4xl font-black text-center mb-12">
                  Comprehensive Indian Legal Coverage
                </h2>
                <div className="flex flex-wrap justify-center gap-4">
                  {[
                    'Constitutional Law', 'Criminal Law (IPC/CrPC)', 'Property Law', 'Employment Law',
                    'Family Law (Hindu/Muslim/Christian)', 'Consumer Protection', 'RTI Act', 'POSH Act',
                    'Industrial Disputes', 'Taxation Law', 'Immigration Law', 'Environmental Law',
                    'Cyber Crime', 'Banking Law', 'Insurance Law', 'Motor Vehicle Act'
                  ].map((area, index) => (
                    <Badge 
                      key={index} 
                      className={`text-sm py-3 px-6 bg-white/10 hover:bg-white/20 text-white border-white/20 hover:border-white/40 transition-all duration-300 transform hover:scale-105 animate-fade-in-up delay-${index * 50}`}
                    >
                      {area}
                    </Badge>
                  ))}
                </div>
              </div>
            </section>

            {/* Enhanced Contact Section */}
            <section className="py-20 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600 to-purple-700"></div>
              <div className="absolute inset-0 bg-black/20"></div>
              
              <div className="relative max-w-6xl mx-auto px-6 text-center">
                <h2 className="text-4xl font-black mb-8 text-white">Need Professional Legal Help?</h2>
                <p className="text-xl text-blue-100 mb-12 max-w-4xl mx-auto leading-relaxed">
                  While LawLens provides comprehensive guidance based on Indian laws, some situations require 
                  professional consultation with advocates enrolled with Bar Council of India.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    { icon: Phone, title: 'NALSA Helpline', desc: 'Call 15100 for free legal aid services across India', color: 'from-blue-400 to-blue-600' },
                    { icon: Mail, title: 'District Legal Services', desc: 'Contact your nearest DLSA for free legal consultation', color: 'from-emerald-400 to-emerald-600' },
                    { icon: Globe, title: 'Online Resources', desc: 'Access eCourts, eFiling, and legal databases', color: 'from-purple-400 to-purple-600' }
                  ].map((contact, index) => {
                    const Icon = contact.icon;
                    return (
                      <Card key={index} className="bg-white/10 backdrop-blur-md border-white/20 text-white hover:bg-white/20 transition-all duration-500 transform hover:-translate-y-2">
                        <CardContent className="pt-8 text-center">
                          <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br ${contact.color} mb-6 shadow-2xl`}>
                            <Icon className="h-8 w-8 text-white" />
                          </div>
                          <h3 className="font-bold text-xl mb-3">{contact.title}</h3>
                          <p className="text-blue-100 leading-relaxed">{contact.desc}</p>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            </section>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Navigation activeSection={activeSection} onSectionChange={setActiveSection} />
      <main>
        {renderContent()}
      </main>
      
      {/* Enhanced Footer */}
      <footer className="bg-gray-900 text-white py-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-gray-900 via-blue-900 to-gray-900"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-6 md:mb-0">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center mr-4 shadow-lg">
                <Scale className="h-7 w-7 text-white" />
              </div>
              <div>
                <span className="text-2xl font-black">LawLens</span>
                <p className="text-sm text-blue-200">Indian AI-Powered Legal Guidance</p>
              </div>
            </div>
            <div className="text-center md:text-right">
              <p className="text-sm text-gray-300 mb-2">
                © 2025 LawLens. Empowering citizens with constitutional knowledge.
              </p>
              <p className="text-xs text-gray-400">
                Based on Constitution of India, IPC, CrPC & Central/State Acts. Not a substitute for professional legal advice.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}