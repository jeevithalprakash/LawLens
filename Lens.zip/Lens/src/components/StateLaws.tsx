import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, MapPin, Scale } from 'lucide-react';
import { stateLaws } from '@/data/legalData';

export default function StateLaws() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedState, setSelectedState] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredLaws, setFilteredLaws] = useState(stateLaws);

  const states = [...new Set(stateLaws.map(law => law.state))];
  const categories = [...new Set(stateLaws.map(law => law.category))];

  const applyFilters = (search: string, state: string, category: string) => {
    let filtered = stateLaws;

    if (search.trim()) {
      filtered = filtered.filter(
        law =>
          law.title.toLowerCase().includes(search.toLowerCase()) ||
          law.description.toLowerCase().includes(search.toLowerCase())
      );
    }

    if (state !== 'all') {
      filtered = filtered.filter(law => law.state === state);
    }

    if (category !== 'all') {
      filtered = filtered.filter(law => law.category === category);
    }

    setFilteredLaws(filtered);
  };

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    applyFilters(value, selectedState, selectedCategory);
  };

  const handleStateChange = (value: string) => {
    setSelectedState(value);
    applyFilters(searchTerm, value, selectedCategory);
  };

  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value);
    applyFilters(searchTerm, selectedState, value);
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Housing': 'bg-blue-100 text-blue-800',
      'Employment': 'bg-green-100 text-green-800',
      'Property': 'bg-purple-100 text-purple-800',
      'Family': 'bg-pink-100 text-pink-800',
      'Criminal': 'bg-red-100 text-red-800'
    };
    return colors[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">State Laws Database</h2>
        <p className="text-lg text-gray-600">
          Browse and search state-specific laws that affect your daily life
        </p>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search laws..."
            value={searchTerm}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-10"
          />
        </div>

        <Select value={selectedState} onValueChange={handleStateChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select State" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All States</SelectItem>
            {states.map(state => (
              <SelectItem key={state} value={state}>{state}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedCategory} onValueChange={handleCategoryChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(category => (
              <SelectItem key={category} value={category}>{category}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Quick Categories */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Browse by Category:</h3>
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Badge
              key={category}
              variant="outline"
              className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 p-2"
              onClick={() => handleCategoryChange(category)}
            >
              {category}
            </Badge>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="space-y-6">
        {filteredLaws.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Scale className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No laws found</h3>
              <p className="text-gray-600">Try adjusting your search criteria or browse all categories.</p>
            </CardContent>
          </Card>
        ) : (
          filteredLaws.map((law) => (
            <Card key={law.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{law.title}</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-600">{law.state}</span>
                      <Badge className={getCategoryColor(law.category)}>
                        {law.category}
                      </Badge>
                    </div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed mb-4">
                  {law.description}
                </p>
                
                {/* Practical Information */}
                <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-400">
                  <h4 className="font-semibold text-green-900 mb-2">What this means for you:</h4>
                  <p className="text-green-800 text-sm">
                    {law.id === 'ca-rent-control' && 
                      "In California, your landlord must follow specific rules when raising rent. Most areas limit increases to 5-10% per year, and you must receive proper written notice."
                    }
                    {law.id === 'ny-tenant-rights' && 
                      "New York tenants have strong protections including rent stabilization in many buildings and the right to renew leases under certain conditions."
                    }
                    {law.id === 'tx-employment' && 
                      "In Texas, employers can terminate employment without cause, but they cannot fire you for illegal reasons like discrimination or whistleblowing."
                    }
                    {law.id === 'fl-homestead' && 
                      "Florida homeowners can protect their primary residence from creditors and may qualify for significant property tax savings through homestead exemption."
                    }
                  </p>
                </div>

                {/* Action Steps */}
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-900 mb-2">Next Steps:</h4>
                  <ul className="text-blue-800 text-sm space-y-1">
                    <li>• Contact your local housing authority for specific requirements</li>
                    <li>• Consult with a local attorney for personalized advice</li>
                    <li>• Check our Legal Aid directory for free assistance</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Disclaimer */}
      <Card className="mt-8 bg-yellow-50 border-yellow-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Scale className="h-6 w-6 text-yellow-600 mt-1" />
            <div>
              <h3 className="font-semibold text-yellow-900 mb-2">Important Notice</h3>
              <p className="text-yellow-800 text-sm">
                Laws change frequently and vary by jurisdiction. This information is for educational purposes only 
                and should not be considered legal advice. Always consult with a qualified attorney for specific 
                legal matters affecting your situation.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}