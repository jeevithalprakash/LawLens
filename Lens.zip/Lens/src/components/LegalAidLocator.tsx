import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Search, MapPin, Phone, Mail, ExternalLink, Users } from 'lucide-react';
import { legalAidOffices } from '@/data/legalData';

export default function LegalAidLocator() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedState, setSelectedState] = useState('all');
  const [filteredOffices, setFilteredOffices] = useState(legalAidOffices);

  const states = [...new Set(legalAidOffices.map(office => office.state))];

  const applyFilters = (search: string, state: string) => {
    let filtered = legalAidOffices;

    if (search.trim()) {
      filtered = filtered.filter(
        office =>
          office.name.toLowerCase().includes(search.toLowerCase()) ||
          office.city.toLowerCase().includes(search.toLowerCase()) ||
          office.services.some(service => 
            service.toLowerCase().includes(search.toLowerCase())
          )
      );
    }

    if (state !== 'all') {
      filtered = filtered.filter(office => office.state === state);
    }

    setFilteredOffices(filtered);
  };

  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    applyFilters(value, selectedState);
  };

  const handleStateChange = (value: string) => {
    setSelectedState(value);
    applyFilters(searchTerm, value);
  };

  const getServiceColor = (service: string) => {
    const colors: Record<string, string> = {
      'Housing': 'bg-blue-100 text-blue-800',
      'Immigration': 'bg-green-100 text-green-800',
      'Family Law': 'bg-purple-100 text-purple-800',
      'Employment': 'bg-orange-100 text-orange-800',
      'Public Benefits': 'bg-teal-100 text-teal-800',
      'Benefits': 'bg-teal-100 text-teal-800',
      'Consumer Rights': 'bg-pink-100 text-pink-800'
    };
    return colors[service] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Find Legal Aid</h2>
        <p className="text-lg text-gray-600">
          Locate free and low-cost legal assistance in your area
        </p>
      </div>

      {/* Search and Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search by city, organization, or service type..."
            value={searchTerm}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="pl-10"
          />
        </div>

        <Select value={selectedState} onValueChange={handleStateChange}>
          <SelectTrigger>
            <SelectValue placeholder="Select State" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All States</SelectItem>
            {states.map(state => (
              <SelectItem key={state} value={state}>{state}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Quick Service Filters */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Find help with:</h3>
        <div className="flex flex-wrap gap-2">
          {['Housing', 'Immigration', 'Family Law', 'Employment', 'Benefits'].map((service) => (
            <Badge
              key={service}
              variant="outline"
              className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 p-2"
              onClick={() => handleSearchChange(service)}
            >
              {service}
            </Badge>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="space-y-6">
        {filteredOffices.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No legal aid offices found</h3>
              <p className="text-gray-600">Try adjusting your search criteria or contact your state bar association for referrals.</p>
            </CardContent>
          </Card>
        ) : (
          filteredOffices.map((office) => (
            <Card key={office.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{office.name}</h3>
                    <div className="flex items-center gap-2 text-gray-600 mb-2">
                      <MapPin className="h-4 w-4" />
                      <span>{office.city}, {office.state}</span>
                    </div>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Contact Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{office.address}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="h-4 w-4" />
                      <a href={`tel:${office.phone}`} className="hover:text-blue-600">
                        {office.phone}
                      </a>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="h-4 w-4" />
                      <a href={`mailto:${office.email}`} className="hover:text-blue-600">
                        {office.email}
                      </a>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm" className="justify-start">
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </Button>
                    <Button variant="outline" size="sm" className="justify-start">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                  </div>
                </div>

                {/* Services */}
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-900 mb-2">Services Provided:</h4>
                  <div className="flex flex-wrap gap-2">
                    {office.services.map((service, index) => (
                      <Badge key={index} className={getServiceColor(service)}>
                        {service}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Information Box */}
                <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-400">
                  <h4 className="font-semibold text-green-900 mb-2">Before You Contact:</h4>
                  <ul className="text-green-800 text-sm space-y-1">
                    <li>• Prepare a brief summary of your legal issue</li>
                    <li>• Gather relevant documents and information</li>
                    <li>• Be ready to provide income information (for eligibility)</li>
                    <li>• Ask about appointment availability and requirements</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Additional Resources */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-6">
            <h3 className="font-semibold text-blue-900 mb-3">National Resources</h3>
            <ul className="text-blue-800 text-sm space-y-2">
              <li>• Legal Services Corporation: <span className="font-mono">lsc.gov</span></li>
              <li>• American Bar Association: <span className="font-mono">americanbar.org</span></li>
              <li>• National Legal Aid & Defender Association</li>
              <li>• Pro Bono Net: <span className="font-mono">probono.net</span></li>
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="p-6">
            <h3 className="font-semibold text-amber-900 mb-3">Eligibility Information</h3>
            <p className="text-amber-800 text-sm mb-2">
              Most legal aid organizations serve clients with income at or below 125-200% of the federal poverty guidelines.
            </p>
            <ul className="text-amber-800 text-sm space-y-1">
              <li>• Income requirements vary by organization</li>
              <li>• Some services available regardless of income</li>
              <li>• Emergency situations may have different criteria</li>
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Emergency Notice */}
      <Card className="mt-6 bg-red-50 border-red-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Phone className="h-6 w-6 text-red-600 mt-1" />
            <div>
              <h3 className="font-semibold text-red-900 mb-2">Emergency Legal Situations</h3>
              <p className="text-red-800 text-sm">
                If you're facing immediate legal emergencies like eviction, domestic violence, or detention, 
                contact emergency legal hotlines or call 911 if you're in immediate danger.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}