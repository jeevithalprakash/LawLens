import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Search, BookOpen } from 'lucide-react';
import { constitutionArticles } from '@/data/legalData';

export default function ConstitutionSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredArticles, setFilteredArticles] = useState(constitutionArticles);

  const handleSearch = (term: string) => {
    setSearchTerm(term);
    if (!term.trim()) {
      setFilteredArticles(constitutionArticles);
      return;
    }

    const filtered = constitutionArticles.filter(
      (article) =>
        article.title.toLowerCase().includes(term.toLowerCase()) ||
        article.content.toLowerCase().includes(term.toLowerCase())
    );
    setFilteredArticles(filtered);
  };

  const highlightText = (text: string, highlight: string) => {
    if (!highlight.trim()) return text;
    
    const parts = text.split(new RegExp(`(${highlight})`, 'gi'));
    return parts.map((part, index) => 
      part.toLowerCase() === highlight.toLowerCase() ? (
        <mark key={index} className="bg-yellow-200 px-1 rounded">
          {part}
        </mark>
      ) : (
        part
      )
    );
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">U.S. Constitution Search</h2>
        <p className="text-lg text-gray-600">
          Search through constitutional articles and amendments to understand your fundamental rights
        </p>
      </div>

      {/* Search Bar */}
      <div className="relative mb-8">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          type="text"
          placeholder="Search constitutional articles, amendments, or keywords..."
          value={searchTerm}
          onChange={(e) => handleSearch(e.target.value)}
          className="pl-10 py-3 text-lg"
        />
      </div>

      {/* Quick Filters */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Popular Searches:</h3>
        <div className="flex flex-wrap gap-2">
          {['First Amendment', 'Fourth Amendment', 'Executive Branch', 'Legislative Branch'].map((term) => (
            <Badge
              key={term}
              variant="outline"
              className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 p-2"
              onClick={() => handleSearch(term)}
            >
              {term}
            </Badge>
          ))}
        </div>
      </div>

      {/* Results */}
      <div className="space-y-6">
        {filteredArticles.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No results found</h3>
              <p className="text-gray-600">Try searching for different keywords or browse all articles.</p>
            </CardContent>
          </Card>
        ) : (
          filteredArticles.map((article) => (
            <Card key={article.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {highlightText(article.title, searchTerm)}
                    </h3>
                    {article.section && (
                      <Badge variant="secondary">{article.section}</Badge>
                    )}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  {highlightText(article.content, searchTerm)}
                </p>
                
                {/* Simple Explanation */}
                <div className="mt-4 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                  <h4 className="font-semibold text-blue-900 mb-2">In Simple Terms:</h4>
                  <p className="text-blue-800 text-sm">
                    {article.id === '1st-amendment' && 
                      "This protects your right to speak freely, practice any religion, and peacefully protest. The government cannot silence you or force you to follow a specific religion."
                    }
                    {article.id === '4th-amendment' && 
                      "Police cannot search your home, car, or belongings without a warrant or probable cause. This protects your privacy from unreasonable government intrusion."
                    }
                    {article.id === 'art1' && 
                      "This establishes Congress (House and Senate) as the branch of government that makes laws. They have the power to create federal legislation."
                    }
                    {article.id === 'art2' && 
                      "This creates the presidency and gives the President the power to enforce laws, command the military, and conduct foreign policy."
                    }
                  </p>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Educational Note */}
      <Card className="mt-8 bg-amber-50 border-amber-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <BookOpen className="h-6 w-6 text-amber-600 mt-1" />
            <div>
              <h3 className="font-semibold text-amber-900 mb-2">Understanding the Constitution</h3>
              <p className="text-amber-800 text-sm">
                The U.S. Constitution is the supreme law of the land. It establishes the framework of government 
                and protects individual rights. When state or local laws conflict with constitutional rights, 
                the Constitution takes precedence.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}