import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Shield, Home, Briefcase, Scale, CheckCircle } from 'lucide-react';
import { rights } from '@/data/legalData';

export default function RightsExplainer() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [filteredRights, setFilteredRights] = useState(rights);

  const categories = [...new Set(rights.map(right => right.category))];

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    if (category === 'all') {
      setFilteredRights(rights);
    } else {
      setFilteredRights(rights.filter(right => right.category === category));
    }
  };

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, JSX.Element> = {
      'Housing': <Home className="h-5 w-5" />,
      'Employment': <Briefcase className="h-5 w-5" />,
      'Constitutional': <Scale className="h-5 w-5" />
    };
    return icons[category] || <Shield className="h-5 w-5" />;
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      'Housing': 'bg-blue-100 text-blue-800 border-blue-300',
      'Employment': 'bg-green-100 text-green-800 border-green-300',
      'Constitutional': 'bg-purple-100 text-purple-800 border-purple-300'
    };
    return colors[category] || 'bg-gray-100 text-gray-800 border-gray-300';
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Know Your Rights</h2>
        <p className="text-lg text-gray-600">
          Understanding your fundamental rights as a citizen in simple, clear language
        </p>
      </div>

      {/* Category Filters */}
      <div className="mb-8">
        <h3 className="text-lg font-semibold mb-4">Browse by Category:</h3>
        <div className="flex flex-wrap gap-2">
          <Badge
            variant={selectedCategory === 'all' ? 'default' : 'outline'}
            className="cursor-pointer p-2"
            onClick={() => handleCategoryChange('all')}
          >
            All Rights
          </Badge>
          {categories.map((category) => (
            <Badge
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              className="cursor-pointer p-2"
              onClick={() => handleCategoryChange(category)}
            >
              <span className="flex items-center gap-1">
                {getCategoryIcon(category)}
                {category}
              </span>
            </Badge>
          ))}
        </div>
      </div>

      {/* Rights Cards */}
      <div className="space-y-6">
        {filteredRights.map((right) => (
          <Card key={right.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${getCategoryColor(right.category)}`}>
                  {getCategoryIcon(right.category)}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">{right.title}</h3>
                  <Badge className={getCategoryColor(right.category)}>
                    {right.category}
                  </Badge>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed mb-6">
                {right.description}
              </p>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="examples">
                  <AccordionTrigger className="text-left">
                    <span className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      What this includes:
                    </span>
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3">
                      {right.examples.map((example, index) => (
                        <div key={index} className="flex items-start gap-3 p-3 bg-green-50 rounded-lg">
                          <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <span className="text-green-800 text-sm">{example}</span>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>

              {/* Practical Guidance */}
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-400">
                <h4 className="font-semibold text-blue-900 mb-2">If your rights are violated:</h4>
                <ul className="text-blue-800 text-sm space-y-1">
                  <li>• Document everything - keep records, photos, and communications</li>
                  <li>• Contact the appropriate agency or authority</li>
                  <li>• Seek legal advice from our Legal Aid directory</li>
                  <li>• Know that you have legal protections and remedies available</li>
                </ul>
              </div>

              {/* Know More Section */}
              {right.id === 'tenant-rights' && (
                <div className="mt-4 p-4 bg-amber-50 rounded-lg">
                  <h4 className="font-semibold text-amber-900 mb-2">Learn More:</h4>
                  <p className="text-amber-800 text-sm">
                    Tenant rights vary by state and city. Check our State Laws section for specific 
                    protections in your area, including rent control, eviction procedures, and habitability standards.
                  </p>
                </div>
              )}

              {right.id === 'employment-rights' && (
                <div className="mt-4 p-4 bg-amber-50 rounded-lg">
                  <h4 className="font-semibold text-amber-900 mb-2">Learn More:</h4>
                  <p className="text-amber-800 text-sm">
                    Employment laws are enforced by federal agencies like the EEOC and Department of Labor, 
                    as well as state agencies. File complaints with the appropriate agency if your rights are violated.
                  </p>
                </div>
              )}

              {right.id === 'constitutional-rights' && (
                <div className="mt-4 p-4 bg-amber-50 rounded-lg">
                  <h4 className="font-semibold text-amber-900 mb-2">Learn More:</h4>
                  <p className="text-amber-800 text-sm">
                    Constitutional rights are your most fundamental protections. They apply to all government 
                    actions and cannot be taken away. Explore our Constitution section for detailed explanations.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Emergency Rights Card */}
      <Card className="mt-8 bg-red-50 border-red-200">
        <CardContent className="p-6">
          <div className="flex items-start gap-3">
            <Shield className="h-6 w-6 text-red-600 mt-1" />
            <div>
              <h3 className="font-semibold text-red-900 mb-2">Emergency Situations</h3>
              <p className="text-red-800 text-sm mb-3">
                If you're facing immediate threats to your safety, rights violations, or legal emergencies:
              </p>
              <ul className="text-red-800 text-sm space-y-1">
                <li>• Call 911 for immediate danger</li>
                <li>• Contact local police for rights violations</li>
                <li>• Reach out to emergency legal hotlines</li>
                <li>• Document everything for later legal action</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}