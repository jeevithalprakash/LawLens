import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Send, Bot, User, Lightbulb, AlertCircle, Scale } from 'lucide-react';
import { generateContextualResponse } from '@/utils/aiService';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

export default function AIQuestionInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Hello! I\'m LawLens AI, your Indian Constitutional and Legal Assistant. I provide guidance based on Indian laws, Constitution, and legal procedures. Whether it\'s property disputes under Transfer of Property Act, employment issues under Industrial Disputes Act, or constitutional rights violations - I\'m here to help you understand your legal options under Indian law.',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const indianLegalExamples = [
    "Property documents are forged, someone filed false complaint. How to prove fraud under Indian law?",
    "Landlord increased rent without notice. What are my rights under Rent Control Act?",
    "Wrongfully terminated from job without notice. Legal remedy under Industrial Disputes Act?",
    "Police searched house without warrant. Were my Article 21 rights violated?",
    "Neighbor encroaching on my land. How to file suit under Transfer of Property Act?",
    "Domestic violence case - how to file under Protection of Women Act 2005?",
    "Consumer complaint against defective product under Consumer Protection Act",
    "RTI application rejected - how to appeal under Right to Information Act?"
  ];

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentQuestion = inputValue;
    setInputValue('');
    setIsLoading(true);

    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: generateContextualResponse(currentQuestion),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsLoading(false);
    }, 2500);
  };

  const handleExampleClick = (question: string) => {
    setInputValue(question);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const formatAIResponse = (content: string) => {
    const sections = content.split('\n\n');
    
    return sections.map((section, index) => {
      if (section.startsWith('**') && section.endsWith('**')) {
        return (
          <div key={index} className="mb-4">
            <h3 className="text-lg font-bold text-gray-900 mb-2 flex items-center gap-2">
              <Scale className="h-4 w-4 text-blue-600" />
              {section.replace(/\*\*/g, '')}
            </h3>
          </div>
        );
      } else if (section.includes('✓') || section.includes('•')) {
        const lines = section.split('\n');
        return (
          <div key={index} className="mb-4">
            {lines.map((line, lineIndex) => {
              if (line.startsWith('**') && line.includes(':**')) {
                return (
                  <h4 key={lineIndex} className="font-semibold text-gray-800 mb-2 mt-3">
                    {line.replace(/\*\*/g, '')}
                  </h4>
                );
              } else if (line.includes('✓') || line.includes('•')) {
                return (
                  <div key={lineIndex} className="flex items-start gap-2 mb-1 pl-2">
                    <span className="text-green-600 mt-1 font-bold">
                      {line.includes('✓') ? '✓' : '•'}
                    </span>
                    <span className="text-sm text-gray-700">
                      {line.replace(/[✓•]\s*/, '')}
                    </span>
                  </div>
                );
              } else if (line.startsWith('- **') && line.includes('**')) {
                return (
                  <div key={lineIndex} className="flex items-start gap-2 mb-1 pl-2">
                    <span className="text-blue-600 mt-1">•</span>
                    <span className="text-sm text-gray-700">
                      <strong>{line.match(/\*\*(.*?)\*\*/)?.[1]}</strong>
                      {line.replace(/- \*\*.*?\*\*/, '')}
                    </span>
                  </div>
                );
              }
              return line.trim() ? (
                <p key={lineIndex} className="text-sm text-gray-700 mb-2 leading-relaxed">
                  {line}
                </p>
              ) : null;
            })}
          </div>
        );
      } else {
        return section.trim() ? (
          <p key={index} className="text-sm text-gray-700 mb-3 leading-relaxed">
            {section}
          </p>
        ) : null;
      }
    });
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4 flex items-center justify-center gap-2">
          <Bot className="h-8 w-8 text-blue-600" />
          LawLens AI Legal Assistant
        </h2>
        <p className="text-lg text-gray-600">
          Constitutional and Legal guidance based on Indian laws, acts, and judicial precedents
        </p>
      </div>

      {/* Indian Legal Examples */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-yellow-500" />
            Common Indian Legal Situations:
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-3">
            {indianLegalExamples.map((question, index) => (
              <Badge
                key={index}
                variant="outline"
                className="cursor-pointer hover:bg-blue-50 hover:border-blue-300 p-3 text-left justify-start h-auto whitespace-normal text-xs leading-relaxed"
                onClick={() => handleExampleClick(question)}
              >
                {question}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Legal Disclaimer - Indian Context */}
      <Card className="mb-6 bg-amber-50 border-amber-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-amber-600 mt-1 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-amber-900 mb-1">Important Legal Notice</h4>
              <p className="text-amber-800 text-sm">
                LawLens AI provides legal information based on Indian Constitution, IPC, CrPC, and various Central/State Acts. 
                This is for educational purposes only. Always consult with a qualified advocate enrolled with Bar Council of India for legal matters.
                For free legal aid, contact your nearest District Legal Services Authority (DLSA).
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chat Messages */}
      <Card className="mb-6">
        <CardContent className="p-0">
          <div className="h-[500px] overflow-y-auto p-4 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${
                  message.type === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                <div
                  className={`flex gap-3 max-w-[90%] ${
                    message.type === 'user' ? 'flex-row-reverse' : 'flex-row'
                  }`}
                >
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      message.type === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gradient-to-r from-purple-500 to-blue-600 text-white'
                    }`}
                  >
                    {message.type === 'user' ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                  </div>
                  <div
                    className={`p-4 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-50 text-gray-900 border shadow-sm'
                    }`}
                  >
                    {message.type === 'user' ? (
                      <p className="text-sm leading-relaxed">{message.content}</p>
                    ) : (
                      <div className="prose prose-sm max-w-none">
                        {formatAIResponse(message.content)}
                      </div>
                    )}
                    <p
                      className={`text-xs mt-3 ${
                        message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-600 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="bg-gray-50 p-4 rounded-lg border shadow-sm">
                  <div className="flex items-center space-x-3">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    </div>
                    <span className="text-sm text-gray-600">Analyzing under Indian legal framework...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Input Area */}
      <div className="flex gap-2">
        <Input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Describe your legal situation with Indian context (mention applicable acts, timeline, location, parties involved)..."
          className="flex-1 text-sm"
          disabled={isLoading}
        />
        <Button 
          onClick={handleSendMessage} 
          disabled={!inputValue.trim() || isLoading}
          className="px-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}